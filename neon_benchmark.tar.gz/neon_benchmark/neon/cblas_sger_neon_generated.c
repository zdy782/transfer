#include "../../blas_case_common.h"
#include <arm_neon.h>

void cblas_sger(
    CBLAS_ORDER order,
    int m,
    int n,
    float alpha,
    const float *x,
    int incx,
    const float *y,
    int incy,
    float *a,
    int lda
) {
    if (order != CblasRowMajor || incx != 1 || incy != 1) {
        return;
    }

    for (int row = 0; row < m; ++row) {
        float scaled_x = alpha * x[row];
        float32x4_t scaled_x_vec = vdupq_n_f32(scaled_x);
        int col = 0;
        for (; col + 4 <= n; col += 4) {
            float32x4_t vy = vld1q_f32(y + col);
            float32x4_t va = vld1q_f32(a + row * lda + col);
            float32x4_t vprod = vmulq_f32(scaled_x_vec, vy);
            va = vaddq_f32(va, vprod);
            vst1q_f32(a + row * lda + col, va);
        }
        for (; col < n; ++col) {
            a[row * lda + col] += scaled_x * y[col];
        }
    }
}
