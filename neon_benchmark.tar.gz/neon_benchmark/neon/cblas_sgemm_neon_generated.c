#include "../../blas_case_common.h"
#include <arm_neon.h>

void cblas_sgemm(
    CBLAS_ORDER order,
    CBLAS_TRANSPOSE transa,
    CBLAS_TRANSPOSE transb,
    int m,
    int n,
    int k,
    float alpha,
    const float *a,
    int lda,
    const float *b,
    int ldb,
    float beta,
    float *c,
    int ldc
) {
    if (order != CblasRowMajor || transa != CblasNoTrans || transb != CblasNoTrans) {
        return;
    }

    for (int row = 0; row < m; ++row) {
        int col = 0;
        for (; col + 4 <= n; col += 4) {
            float32x4_t vc = vld1q_f32(c + row * ldc + col);
            vc = vmulq_n_f32(vc, beta);
            vst1q_f32(c + row * ldc + col, vc);
        }
        for (; col < n; ++col) {
            c[row * ldc + col] *= beta;
        }

        for (int depth = 0; depth < k; ++depth) {
            float scaled_a = alpha * a[row * lda + depth];
            float32x4_t scaled_a_vec = vdupq_n_f32(scaled_a);
            col = 0;
            for (; col + 4 <= n; col += 4) {
                float32x4_t vb = vld1q_f32(b + depth * ldb + col);
                float32x4_t vc = vld1q_f32(c + row * ldc + col);
                vc = vfmaq_f32(vc, scaled_a_vec, vb);
                vst1q_f32(c + row * ldc + col, vc);
            }
            for (; col < n; ++col) {
                c[row * ldc + col] += scaled_a * b[depth * ldb + col];
            }
        }
    }
}
