#include "../../blas_case_common.h"
#include <arm_neon.h>

float cblas_sdot(int n, const float *x, int incx, const float *y, int incy) {
    float accum = 0.0f;

    if (n <= 0) {
        return 0.0f;
    }

    if (incx == 1 && incy == 1) {
        float32x4_t vsum = vdupq_n_f32(0.0f);
        int i = 0;
        for (; i + 4 <= n; i += 4) {
            float32x4_t vx = vld1q_f32(x + i);
            float32x4_t vy = vld1q_f32(y + i);
            vsum = vfmaq_f32(vsum, vx, vy);
        }
        float32x2_t vsum_low = vget_low_f32(vsum);
        float32x2_t vsum_high = vget_high_f32(vsum);
        vsum_low = vadd_f32(vsum_low, vsum_high);
        accum = vget_lane_f32(vsum_low, 0) + vget_lane_f32(vsum_low, 1);
        for (; i < n; ++i) {
            accum += x[i] * y[i];
        }
        return accum;
    }

    {
        int ix = 0;
        int iy = 0;
        for (int index = 0; index < n; ++index) {
            accum += x[ix] * y[iy];
            ix += incx;
            iy += incy;
        }
    }
    return accum;
}
