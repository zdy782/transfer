#include "../../blas_case_common.h"
#include <arm_neon.h>

void cblas_saxpy(int n, float alpha, const float *x, int incx, float *y, int incy) {
    if (n <= 0) {
        return;
    }

    if (incx == 1 && incy == 1) {
        float32x4_t alpha_vec = vdupq_n_f32(alpha);
        int i = 0;
        for (; i + 4 <= n; i += 4) {
            float32x4_t vx = vld1q_f32(x + i);
            float32x4_t vy = vld1q_f32(y + i);
            float32x4_t vprod = vmulq_f32(alpha_vec, vx);
            vy = vaddq_f32(vy, vprod);
            vst1q_f32(y + i, vy);
        }
        for (; i < n; ++i) {
            y[i] += alpha * x[i];
        }
        return;
    }

    {
        int ix = 0;
        int iy = 0;
        for (int index = 0; index < n; ++index) {
            y[iy] += alpha * x[ix];
            ix += incx;
            iy += incy;
        }
    }
}
