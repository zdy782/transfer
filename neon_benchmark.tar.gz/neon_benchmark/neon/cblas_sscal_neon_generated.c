#include "../../blas_case_common.h"
#include <arm_neon.h>

void cblas_sscal(int n, float alpha, float *x, int incx) {
    if (n <= 0) {
        return;
    }

    if (incx == 1) {
        float32x4_t alpha_vec = vdupq_n_f32(alpha);
        int i = 0;
        for (; i + 4 <= n; i += 4) {
            float32x4_t vx = vld1q_f32(x + i);
            vx = vmulq_f32(vx, alpha_vec);
            vst1q_f32(x + i, vx);
        }
        for (; i < n; ++i) {
            x[i] *= alpha;
        }
        return;
    }

    {
        int ix = 0;
        for (int index = 0; index < n; ++index) {
            x[ix] *= alpha;
            ix += incx;
        }
    }
}
