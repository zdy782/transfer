#include "../../blas_case_common.h"
#include <arm_neon.h>

void cblas_scopy(int n, const float *x, int incx, float *y, int incy) {
    if (n <= 0) {
        return;
    }

    if (incx == 1 && incy == 1) {
        int i = 0;
        for (; i + 4 <= n; i += 4) {
            float32x4_t vx = vld1q_f32(x + i);
            vst1q_f32(y + i, vx);
        }
        for (; i < n; ++i) {
            y[i] = x[i];
        }
        return;
    }

    {
        int ix = 0;
        int iy = 0;
        for (int index = 0; index < n; ++index) {
            y[iy] = x[ix];
            ix += incx;
            iy += incy;
        }
    }
}
