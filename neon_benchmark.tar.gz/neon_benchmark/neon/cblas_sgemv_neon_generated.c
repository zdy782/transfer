#include "../blas_case_common.h"
#include <arm_neon.h>

void cblas_sgemv(
    CBLAS_ORDER order,
    CBLAS_TRANSPOSE trans,
    int m,
    int n,
    float alpha,
    const float *a,
    int lda,
    const float *x,
    int incx,
    float beta,
    float *y,
    int incy
) {
    if (order != CblasRowMajor || trans != CblasNoTrans || incx != 1 || incy != 1) {
        return;
    }

    for (int row = 0; row < m; ++row) {
        float32x4_t vsum = vdupq_n_f32(0.0f);
        int col = 0;
        for (; col + 4 <= n; col += 4) {
            float32x4_t va = vld1q_f32(a + row * lda + col);
            float32x4_t vx = vld1q_f32(x + col);
            vsum = vfmaq_f32(vsum, va, vx);
        }
        float32x2_t vsum_low = vget_low_f32(vsum);
        float32x2_t vsum_high = vget_high_f32(vsum);
        vsum_low = vadd_f32(vsum_low, vsum_high);
        float accum = vget_lane_f32(vsum_low, 0) + vget_lane_f32(vsum_low, 1);
        for (; col < n; ++col) {
            accum += a[row * lda + col] * x[col];
        }

        y[row] = (alpha * accum) + (beta * y[row]);
    }
}
