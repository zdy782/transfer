#include "../../blas_case_common.h"
#include <arm_neon.h>

void cblas_ssyrk(
    CBLAS_ORDER order,
    CBLAS_UPLO uplo,
    CBLAS_TRANSPOSE trans,
    int n,
    int k,
    float alpha,
    const float *a,
    int lda,
    float beta,
    float *c,
    int ldc
) {
    if (order != CblasRowMajor || uplo != CblasUpper || trans != CblasNoTrans) {
        return;
    }

    for (int row = 0; row < n; ++row) {
        for (int col = row; col < n; ++col) {
            float32x4_t vsum = vdupq_n_f32(0.0f);
            int depth = 0;
            for (; depth + 4 <= k; depth += 4) {
                float32x4_t va_row = vld1q_f32(a + row * lda + depth);
                float32x4_t va_col = vld1q_f32(a + col * lda + depth);
                vsum = vfmaq_f32(vsum, va_row, va_col);
            }
            float32x2_t vsum_low = vget_low_f32(vsum);
            float32x2_t vsum_high = vget_high_f32(vsum);
            vsum_low = vadd_f32(vsum_low, vsum_high);
            float accum = vget_lane_f32(vsum_low, 0) + vget_lane_f32(vsum_low, 1);
            for (; depth < k; ++depth) {
                accum += a[row * lda + depth] * a[col * lda + depth];
            }

            c[row * ldc + col] = (alpha * accum) + (beta * c[row * ldc + col]);
        }
    }
}
