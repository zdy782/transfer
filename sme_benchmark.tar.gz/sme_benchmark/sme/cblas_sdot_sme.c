#include <arm_sme.h>
#include <arm_sve.h>
#include <stdint.h>

// SME streaming vectorization of cblas_sdot
// Original: accum += x[index] * y[index] for unit-stride path
// Uses horizontal reduction (svaddv_f32) for accumulation

float cblas_sdot(int n, const float *x, int incx, const float *y, int incy) __arm_streaming;

float cblas_sdot(int n, const float *x, int incx, const float *y, int incy) __arm_streaming {
    if (n <= 0) {
        return 0.0f;
    }

    // Unit-stride fast path
    if (incx == 1 && incy == 1) {
        const int vl = (int)svcntw();
        svfloat32_t v_acc = svdup_n_f32(0.0f);

        for (int index = 0; index < n; index += vl) {
            svbool_t pg = svwhilelt_b32((uint64_t)index, (uint64_t)n);
            svfloat32_t vx = svld1_f32(pg, x + index);
            svfloat32_t vy = svld1_f32(pg, y + index);
            // Accumulate element-wise product into vector accumulator
            v_acc = svmla_f32_m(pg, v_acc, vx, vy);
        }

        // Final horizontal reduction
        float accum = svaddv_f32(svptrue_b32(), v_acc);
        return accum;
    }

    // Strided fallback (scalar)
    float accum = 0.0f;
    int ix = 0;
    int iy = 0;
    for (int index = 0; index < n; ++index) {
        accum += x[ix] * y[iy];
        ix += incx;
        iy += incy;
    }
    return accum;
}