#include <arm_sme.h>
#include <arm_sve.h>
#include <stdint.h>
#include "../../blas_case_common.h"

// SME streaming vectorization of cblas_sger
// Original: a[row * lda + col] += scaled_x * y[col]
// Inner loop vectorizes over col dimension

void cblas_sger(
    CBLAS_ORDER order,
    int m,
    int n,
    float alpha,
    const float *x,
    int incx,
    const float *y,
    int incy,
    float *a,
    int lda
) __arm_streaming;

void cblas_sger(
    CBLAS_ORDER order,
    int m,
    int n,
    float alpha,
    const float *x,
    int incx,
    const float *y,
    int incy,
    float *a,
    int lda
) __arm_streaming {
    if (order != CblasRowMajor || incx != 1 || incy != 1) {
        return;
    }

    const int vl = (int)svcntw();

    for (int row = 0; row < m; ++row) {
        float scaled_x = alpha * x[row];
        svfloat32_t v_scaled_x = svdup_n_f32(scaled_x);
        float *a_row = a + row * lda;

        for (int col = 0; col < n; col += vl) {
            svbool_t pg = svwhilelt_b32((uint64_t)col, (uint64_t)n);
            svfloat32_t vy = svld1_f32(pg, y + col);
            svfloat32_t va = svld1_f32(pg, a_row + col);
            va = svmla_f32_x(pg, va, v_scaled_x, vy);
            svst1_f32(pg, a_row + col, va);
        }
    }
}