#include <arm_sme.h>
#include <arm_sve.h>
#include <stdint.h>
#include "../blas_case_common.h"

// SME streaming vectorization of cblas_sgemv
// Original: y[row] = alpha * sum(a[row,:]*x) + beta * y[row]
// Inner loop: accum += a[row * lda + col] * x[col]

void cblas_sgemv(
    CBLAS_ORDER order,
    CBLAS_TRANSPOSE trans,
    int m,
    int n,
    float alpha,
    const float *a,
    int lda,
    const float *x,
    int incx,
    float beta,
    float *y,
    int incy
) __arm_streaming;

void cblas_sgemv(
    CBLAS_ORDER order,
    CBLAS_TRANSPOSE trans,
    int m,
    int n,
    float alpha,
    const float *a,
    int lda,
    const float *x,
    int incx,
    float beta,
    float *y,
    int incy
) __arm_streaming {
    if (order != CblasRowMajor || trans != CblasNoTrans || incx != 1 || incy != 1) {
        return;
    }

    const int vl = (int)svcntw();

    for (int row = 0; row < m; ++row) {
        // Inner reduction: accum = sum(a[row, col] * x[col])
        svfloat32_t v_acc = svdup_n_f32(0.0f);
        const float *a_row = a + row * lda;

        for (int col = 0; col < n; col += vl) {
            svbool_t pg = svwhilelt_b32((uint64_t)col, (uint64_t)n);
            svfloat32_t va = svld1_f32(pg, a_row + col);
            svfloat32_t vx = svld1_f32(pg, x + col);
            v_acc = svmla_f32_m(pg, v_acc, va, vx);
        }

        float accum = svaddv_f32(svptrue_b32(), v_acc);
        y[row] = (alpha * accum) + (beta * y[row]);
    }
}