#include <arm_sme.h>
#include <arm_sve.h>
#include <stdint.h>

// SME streaming vectorization of cblas_saxpy
// Original: y[index] += alpha * x[index] for unit-stride path

void cblas_saxpy(int n, float alpha, const float *x, int incx, float *y, int incy) __arm_streaming;

void cblas_saxpy(int n, float alpha, const float *x, int incx, float *y, int incy) __arm_streaming {
    if (n <= 0) {
        return;
    }

    // Unit-stride fast path
    if (incx == 1 && incy == 1) {
        const int vl = (int)svcntw();
        svfloat32_t v_alpha = svdup_n_f32(alpha);

        for (int index = 0; index < n; index += vl) {
            svbool_t pg = svwhilelt_b32((uint64_t)index, (uint64_t)n);
            svfloat32_t vx = svld1_f32(pg, x + index);
            svfloat32_t vy = svld1_f32(pg, y + index);
            vy = svmla_f32_x(pg, vy, v_alpha, vx);
            svst1_f32(pg, y + index, vy);
        }
        return;
    }

    // Strided fallback (scalar)
    int ix = 0;
    int iy = 0;
    for (int index = 0; index < n; ++index) {
        y[iy] += alpha * x[ix];
        ix += incx;
        iy += incy;
    }
}