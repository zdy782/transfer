#include <arm_sme.h>
#include <arm_sve.h>
#include <stdint.h>
#include "../../blas_case_common.h"

// SME streaming vectorization of cblas_ssyrk
// Original: C[row, col] = alpha * sum(A[row, d] * A[col, d]) + beta * C[row, col]
// Upper triangle, row-major, no-trans path
// Outer: row over n
// Middle: col from row to n
// Inner: depth over k (reduction)

void cblas_ssyrk(
    CBLAS_ORDER order,
    CBLAS_UPLO uplo,
    CBLAS_TRANSPOSE trans,
    int n,
    int k,
    float alpha,
    const float *a,
    int lda,
    float beta,
    float *c,
    int ldc
) __arm_streaming;

void cblas_ssyrk(
    CBLAS_ORDER order,
    CBLAS_UPLO uplo,
    CBLAS_TRANSPOSE trans,
    int n,
    int k,
    float alpha,
    const float *a,
    int lda,
    float beta,
    float *c,
    int ldc
) __arm_streaming {
    if (order != CblasRowMajor || uplo != CblasUpper || trans != CblasNoTrans) {
        return;
    }

    const int vl = (int)svcntw();

    for (int row = 0; row < n; ++row) {
        const float *a_row = a + row * lda;

        for (int col = row; col < n; ++col) {
            const float *a_col = a + col * lda;

            // Inner reduction: accum = sum(A[row, d] * A[col, d])
            svfloat32_t v_acc = svdup_n_f32(0.0f);

            for (int depth = 0; depth < k; depth += vl) {
                svbool_t pg = svwhilelt_b32((uint64_t)depth, (uint64_t)k);
                svfloat32_t va_row = svld1_f32(pg, a_row + depth);
                svfloat32_t va_col = svld1_f32(pg, a_col + depth);
                v_acc = svmla_f32_m(pg, v_acc, va_row, va_col);
            }

            float accum = svaddv_f32(svptrue_b32(), v_acc);
            c[row * ldc + col] = (alpha * accum) + (beta * c[row * ldc + col]);
        }
    }
}