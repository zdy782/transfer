#include <arm_sme.h>
#include <arm_sve.h>
#include <stdint.h>
#include "../blas_case_common.h"

// SME streaming vectorization of cblas_sgemm
// Original: C = alpha * A * B + beta * C
// Outer: row over m
// Middle: depth over k
// Inner: col over n (vectorized)

void cblas_sgemm(
    CBLAS_ORDER order,
    CBLAS_TRANSPOSE transa,
    CBLAS_TRANSPOSE transb,
    int m,
    int n,
    int k,
    float alpha,
    const float *a,
    int lda,
    const float *b,
    int ldb,
    float beta,
    float *c,
    int ldc
) __arm_streaming;

void cblas_sgemm(
    CBLAS_ORDER order,
    CBLAS_TRANSPOSE transa,
    CBLAS_TRANSPOSE transb,
    int m,
    int n,
    int k,
    float alpha,
    const float *a,
    int lda,
    const float *b,
    int ldb,
    float beta,
    float *c,
    int ldc
) __arm_streaming {
    if (order != CblasRowMajor || transa != CblasNoTrans || transb != CblasNoTrans) {
        return;
    }

    const int vl = (int)svcntw();

    for (int row = 0; row < m; ++row) {
        float *c_row = c + row * ldc;
        const float *a_row = a + row * lda;

        // Scale C row by beta
        for (int col = 0; col < n; col += vl) {
            svbool_t pg = svwhilelt_b32((uint64_t)col, (uint64_t)n);
            svfloat32_t vc = svld1_f32(pg, c_row + col);
            vc = svmul_f32_x(pg, vc, svdup_n_f32(beta));
            svst1_f32(pg, c_row + col, vc);
        }

        // Accumulate A[row, depth] * B[depth, col] into C[row, col]
        for (int depth = 0; depth < k; ++depth) {
            float scaled_a = alpha * a_row[depth];
            svfloat32_t v_scaled_a = svdup_n_f32(scaled_a);
            const float *b_row = b + depth * ldb;

            for (int col = 0; col < n; col += vl) {
                svbool_t pg = svwhilelt_b32((uint64_t)col, (uint64_t)n);
                svfloat32_t vb = svld1_f32(pg, b_row + col);
                svfloat32_t vc = svld1_f32(pg, c_row + col);
                vc = svmla_f32_x(pg, vc, v_scaled_a, vb);
                svst1_f32(pg, c_row + col, vc);
            }
        }
    }
}