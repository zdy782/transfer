#include <arm_sme.h>
#include <arm_sve.h>
#include <stdint.h>

// SME streaming vectorization of cblas_sscal
// Original: x[index] *= alpha for unit-stride path

void cblas_sscal(int n, float alpha, float *x, int incx) __arm_streaming;

void cblas_sscal(int n, float alpha, float *x, int incx) __arm_streaming {
    if (n <= 0) {
        return;
    }

    // Unit-stride fast path
    if (incx == 1) {
        const int vl = (int)svcntw();
        svfloat32_t v_alpha = svdup_n_f32(alpha);

        for (int index = 0; index < n; index += vl) {
            svbool_t pg = svwhilelt_b32((uint64_t)index, (uint64_t)n);
            svfloat32_t vx = svld1_f32(pg, x + index);
            vx = svmul_f32_x(pg, vx, v_alpha);
            svst1_f32(pg, x + index, vx);
        }
        return;
    }

    // Strided fallback (scalar)
    int ix = 0;
    for (int index = 0; index < n; ++index) {
        x[ix] *= alpha;
        ix += incx;
    }
}