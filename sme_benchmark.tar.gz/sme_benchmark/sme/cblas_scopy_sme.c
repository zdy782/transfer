#include <arm_sme.h>
#include <arm_sve.h>
#include <stdint.h>

// SME streaming vectorization of cblas_scopy
// Original: y[index] = x[index] for unit-stride path

void cblas_scopy(int n, const float *x, int incx, float *y, int incy) __arm_streaming;

void cblas_scopy(int n, const float *x, int incx, float *y, int incy) __arm_streaming {
    if (n <= 0) {
        return;
    }

    // Unit-stride fast path
    if (incx == 1 && incy == 1) {
        const int vl = (int)svcntw();

        for (int index = 0; index < n; index += vl) {
            svbool_t pg = svwhilelt_b32((uint64_t)index, (uint64_t)n);
            svfloat32_t vx = svld1_f32(pg, x + index);
            svst1_f32(pg, y + index, vx);
        }
        return;
    }

    // Strided fallback (scalar)
    int ix = 0;
    int iy = 0;
    for (int index = 0; index < n; ++index) {
        y[iy] = x[ix];
        ix += incx;
        iy += incy;
    }
}