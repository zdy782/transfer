#ifndef DRIVER_COMMON_H
#define DRIVER_COMMON_H

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

// CBLAS enums
typedef enum {
    CblasRowMajor = 101,
    CblasColMajor = 102,
} CBLAS_ORDER;

typedef enum {
    CblasNoTrans = 111,
    CblasTrans = 112,
} CBLAS_TRANSPOSE;

typedef enum {
    CblasUpper = 121,
    CblasLower = 122,
} CBLAS_UPLO;

// Timing utilities
static inline double get_seconds(void) {
    struct timespec ts;
    timespec_get(&ts, TIME_UTC);
    return (double)ts.tv_sec + ((double)ts.tv_nsec / 1e9);
}

// Data initialization
static inline void fill_vector(float *data, int count, float scale) {
    for (int i = 0; i < count; ++i) {
        data[i] = (float)((i % 29) - 14) * scale;
    }
}

static inline void fill_matrix(float *data, int rows, int cols, int ld, float scale) {
    for (int r = 0; r < rows; ++r) {
        for (int c = 0; c < cols; ++c) {
            data[r * ld + c] = (float)(((r * 13) + (c * 7)) % 41 - 20) * scale;
        }
    }
}

static inline void fill_symmetric(float *data, int n, int ld, float scale) {
    for (int r = 0; r < n; ++r) {
        for (int c = r; c < n; ++c) {
            float v = (float)(((r * 11) + (c * 5)) % 37 - 18) * scale;
            data[r * ld + c] = v;
            data[c * ld + r] = v;
        }
    }
}

// Validation utilities
static inline float max_abs_diff(const float *a, const float *b, int count) {
    float max_diff = 0.0f;
    for (int i = 0; i < count; ++i) {
        float diff = fabsf(a[i] - b[i]);
        if (diff > max_diff) max_diff = diff;
    }
    return max_diff;
}

static inline double checksum(const float *data, int count) {
    double sum = 0.0;
    for (int i = 0; i < count; ++i) {
        sum += (double)data[i];
    }
    return sum;
}

// Reference implementations (scalar)
static inline void ref_saxpy(int n, float alpha, const float *x, int incx, float *y, int incy) {
    int ix = 0, iy = 0;
    for (int i = 0; i < n; ++i) {
        y[iy] += alpha * x[ix];
        ix += incx;
        iy += incy;
    }
}

static inline void ref_scopy(int n, const float *x, int incx, float *y, int incy) {
    int ix = 0, iy = 0;
    for (int i = 0; i < n; ++i) {
        y[iy] = x[ix];
        ix += incx;
        iy += incy;
    }
}

static inline float ref_sdot(int n, const float *x, int incx, const float *y, int incy) {
    float sum = 0.0f;
    int ix = 0, iy = 0;
    for (int i = 0; i < n; ++i) {
        sum += x[ix] * y[iy];
        ix += incx;
        iy += incy;
    }
    return sum;
}

static inline void ref_sscal(int n, float alpha, float *x, int incx) {
    int ix = 0;
    for (int i = 0; i < n; ++i) {
        x[ix] *= alpha;
        ix += incx;
    }
}

static inline void ref_sgemv(CBLAS_ORDER order, CBLAS_TRANSPOSE trans,
                             int m, int n, float alpha, const float *a, int lda,
                             const float *x, int incx, float beta, float *y, int incy) {
    if (order != CblasRowMajor || trans != CblasNoTrans) return;

    for (int i = 0; i < m; ++i) {
        float sum = 0.0f;
        for (int j = 0; j < n; ++j) {
            sum += a[i * lda + j] * x[j * incx];
        }
        y[i * incy] = alpha * sum + beta * y[i * incy];
    }
}

static inline void ref_sger(CBLAS_ORDER order, int m, int n, float alpha,
                            const float *x, int incx, const float *y, int incy,
                            float *a, int lda) {
    if (order != CblasRowMajor) return;

    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) {
            a[i * lda + j] += alpha * x[i * incx] * y[j * incy];
        }
    }
}

static inline void ref_sgemm(CBLAS_ORDER order, CBLAS_TRANSPOSE transa, CBLAS_TRANSPOSE transb,
                             int m, int n, int k, float alpha, const float *a, int lda,
                             const float *b, int ldb, float beta, float *c, int ldc) {
    if (order != CblasRowMajor || transa != CblasNoTrans || transb != CblasNoTrans) return;

    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) {
            float sum = 0.0f;
            for (int p = 0; p < k; ++p) {
                sum += a[i * lda + p] * b[p * ldb + j];
            }
            c[i * ldc + j] = alpha * sum + beta * c[i * ldc + j];
        }
    }
}

static inline void ref_ssyrk(CBLAS_ORDER order, CBLAS_UPLO uplo, CBLAS_TRANSPOSE trans,
                             int n, int k, float alpha, const float *a, int lda,
                             float beta, float *c, int ldc) {
    if (order != CblasRowMajor || uplo != CblasUpper || trans != CblasNoTrans) return;

    for (int i = 0; i < n; ++i) {
        for (int j = i; j < n; ++j) {
            float sum = 0.0f;
            for (int p = 0; p < k; ++p) {
                sum += a[i * lda + p] * a[j * lda + p];
            }
            c[i * ldc + j] = alpha * sum + beta * c[i * ldc + j];
        }
    }
}

// Benchmark configuration
#define WARMUP_ITERATIONS 3
#define BENCHMARK_ITERATIONS 10
#define TOLERANCE 1e-3f  // Allow small accumulated floating point errors

#endif