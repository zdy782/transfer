// Benchmark driver for CBLAS Level 1/2/3 functions
// Compile with appropriate ISA flags

#include "../driver_common.h"
#include <math.h>

// Function declarations - will be linked from generated C files
extern void cblas_saxpy(int n, float alpha, const float *x, int incx, float *y, int incy);
extern void cblas_scopy(int n, const float *x, int incx, float *y, int incy);
extern float cblas_sdot(int n, const float *x, int incx, const float *y, int incy);
extern void cblas_sscal(int n, float alpha, float *x, int incx);
extern void cblas_sgemv(CBLAS_ORDER order, CBLAS_TRANSPOSE trans,
                        int m, int n, float alpha, const float *a, int lda,
                        const float *x, int incx, float beta, float *y, int incy);
extern void cblas_sger(CBLAS_ORDER order, int m, int n, float alpha,
                       const float *x, int incx, const float *y, int incy,
                       float *a, int lda);
extern void cblas_sgemm(CBLAS_ORDER order, CBLAS_TRANSPOSE transa, CBLAS_TRANSPOSE transb,
                        int m, int n, int k, float alpha, const float *a, int lda,
                        const float *b, int ldb, float beta, float *c, int ldc);
extern void cblas_ssyrk(CBLAS_ORDER order, CBLAS_UPLO uplo, CBLAS_TRANSPOSE trans,
                        int n, int k, float alpha, const float *a, int lda,
                        float beta, float *c, int ldc);

// Test sizes
static const int TEST_N = 4096;      // Vector length
static const int TEST_M = 256;       // Matrix rows
static const int TEST_K = 256;       // Matrix inner dimension

// FLOP counts per operation
// saxpy: n multiply + n add = 2n
// scopy: 0 (memory only)
// sdot:  n multiply + n add = 2n
// sscal: n multiply = n
// sgemv: 2*m*n (alpha*A*x + beta*y)
// sger:  2*m*n (alpha*x*y^T)
// sgemm: 2*m*n*k (classic GEMM)
// ssyrk: n*n*k (symmetric, ~half of gemm)

static double calc_gflops(double flops, double time_seconds, int iterations) {
    if (time_seconds <= 0.0) return 0.0;
    double total_flops = flops * iterations;
    return total_flops / time_seconds / 1e9;
}

static void benchmark_saxpy(void) {
    float *x = malloc(TEST_N * sizeof(float));
    float *y_opt = malloc(TEST_N * sizeof(float));
    float *y_ref = malloc(TEST_N * sizeof(float));
    if (!x || !y_opt || !y_ref) {
        fprintf(stderr, "saxpy: memory allocation failed\n");
        return;
    }

    fill_vector(x, TEST_N, 0.1f);
    fill_vector(y_opt, TEST_N, 0.5f);
    memcpy(y_ref, y_opt, TEST_N * sizeof(float));
    float alpha = 2.0f;

    // Warmup
    for (int i = 0; i < WARMUP_ITERATIONS; ++i) {
        cblas_saxpy(TEST_N, alpha, x, 1, y_opt, 1);
    }

    // Benchmark optimized
    double t_opt_start = get_seconds();
    for (int i = 0; i < BENCHMARK_ITERATIONS; ++i) {
        cblas_saxpy(TEST_N, alpha, x, 1, y_opt, 1);
    }
    double t_opt = get_seconds() - t_opt_start;

    // Reference
    double t_ref_start = get_seconds();
    for (int i = 0; i < BENCHMARK_ITERATIONS; ++i) {
        ref_saxpy(TEST_N, alpha, x, 1, y_ref, 1);
    }
    double t_ref = get_seconds() - t_ref_start;

    double flops = 2.0 * TEST_N;
    double gflops_opt = calc_gflops(flops, t_opt, BENCHMARK_ITERATIONS);
    double gflops_ref = calc_gflops(flops, t_ref, BENCHMARK_ITERATIONS);

    float diff = max_abs_diff(y_opt, y_ref, TEST_N);
    printf("saxpy: ref=%.6fs(%7.2f GFLOPS) opt=%.6fs(%7.2f GFLOPS) speedup=%.2fx max_diff=%.6f %s\n",
           t_ref, gflops_ref, t_opt, gflops_opt, t_ref/t_opt, diff, diff < TOLERANCE ? "PASS" : "FAIL");

    free(x); free(y_opt); free(y_ref);
}

static void benchmark_scopy(void) {
    float *x = malloc(TEST_N * sizeof(float));
    float *y_opt = malloc(TEST_N * sizeof(float));
    float *y_ref = malloc(TEST_N * sizeof(float));
    if (!x || !y_opt || !y_ref) return;

    fill_vector(x, TEST_N, 0.1f);

    // Warmup + Benchmark
    for (int i = 0; i < WARMUP_ITERATIONS; ++i) cblas_scopy(TEST_N, x, 1, y_opt, 1);
    double t_opt_start = get_seconds();
    for (int i = 0; i < BENCHMARK_ITERATIONS; ++i) cblas_scopy(TEST_N, x, 1, y_opt, 1);
    double t_opt = get_seconds() - t_opt_start;

    double t_ref_start = get_seconds();
    for (int i = 0; i < BENCHMARK_ITERATIONS; ++i) ref_scopy(TEST_N, x, 1, y_ref, 1);
    double t_ref = get_seconds() - t_ref_start;

    // scopy has no FLOPs, show bandwidth instead
    double bytes = TEST_N * sizeof(float) * 2; // read + write
    double bw_opt = (bytes * BENCHMARK_ITERATIONS) / t_opt / 1e9; // GB/s
    double bw_ref = (bytes * BENCHMARK_ITERATIONS) / t_ref / 1e9; // GB/s

    float diff = max_abs_diff(y_opt, y_ref, TEST_N);
    printf("scopy: ref=%.6fs(%7.2f GB/s) opt=%.6fs(%7.2f GB/s) speedup=%.2fx max_diff=%.6f %s\n",
           t_ref, bw_ref, t_opt, bw_opt, t_ref/t_opt, diff, diff < TOLERANCE ? "PASS" : "FAIL");

    free(x); free(y_opt); free(y_ref);
}

static void benchmark_sdot(void) {
    float *x = malloc(TEST_N * sizeof(float));
    float *y = malloc(TEST_N * sizeof(float));
    if (!x || !y) return;

    fill_vector(x, TEST_N, 0.1f);
    fill_vector(y, TEST_N, 0.2f);

    for (int i = 0; i < WARMUP_ITERATIONS; ++i) cblas_sdot(TEST_N, x, 1, y, 1);
    double t_opt_start = get_seconds();
    float opt_result = 0.0f;
    for (int i = 0; i < BENCHMARK_ITERATIONS; ++i) opt_result = cblas_sdot(TEST_N, x, 1, y, 1);
    double t_opt = get_seconds() - t_opt_start;

    double t_ref_start = get_seconds();
    float ref_result = 0.0f;
    for (int i = 0; i < BENCHMARK_ITERATIONS; ++i) ref_result = ref_sdot(TEST_N, x, 1, y, 1);
    double t_ref = get_seconds() - t_ref_start;

    double flops = 2.0 * TEST_N;
    double gflops_opt = calc_gflops(flops, t_opt, BENCHMARK_ITERATIONS);
    double gflops_ref = calc_gflops(flops, t_ref, BENCHMARK_ITERATIONS);

    float diff = fabsf(opt_result - ref_result);
    printf("sdot:  ref=%.6fs(%7.2f GFLOPS) opt=%.6fs(%7.2f GFLOPS) speedup=%.2fx diff=%.6f %s\n",
           t_ref, gflops_ref, t_opt, gflops_opt, t_ref/t_opt, diff, diff < TOLERANCE ? "PASS" : "FAIL");

    free(x); free(y);
}

static void benchmark_sscal(void) {
    float *x_opt = malloc(TEST_N * sizeof(float));
    float *x_ref = malloc(TEST_N * sizeof(float));
    if (!x_opt || !x_ref) return;

    fill_vector(x_opt, TEST_N, 0.5f);
    memcpy(x_ref, x_opt, TEST_N * sizeof(float));
    float alpha = 3.0f;

    for (int i = 0; i < WARMUP_ITERATIONS; ++i) cblas_sscal(TEST_N, alpha, x_opt, 1);
    double t_opt_start = get_seconds();
    for (int i = 0; i < BENCHMARK_ITERATIONS; ++i) cblas_sscal(TEST_N, alpha, x_opt, 1);
    double t_opt = get_seconds() - t_opt_start;

    double t_ref_start = get_seconds();
    for (int i = 0; i < BENCHMARK_ITERATIONS; ++i) ref_sscal(TEST_N, alpha, x_ref, 1);
    double t_ref = get_seconds() - t_ref_start;

    double flops = TEST_N;
    double gflops_opt = calc_gflops(flops, t_opt, BENCHMARK_ITERATIONS);
    double gflops_ref = calc_gflops(flops, t_ref, BENCHMARK_ITERATIONS);

    float diff = max_abs_diff(x_opt, x_ref, TEST_N);
    printf("sscal: ref=%.6fs(%7.2f GFLOPS) opt=%.6fs(%7.2f GFLOPS) speedup=%.2fx max_diff=%.6f %s\n",
           t_ref, gflops_ref, t_opt, gflops_opt, t_ref/t_opt, diff, diff < TOLERANCE ? "PASS" : "FAIL");

    free(x_opt); free(x_ref);
}

static void benchmark_sgemv(void) {
    int lda = TEST_N;
    float *a = malloc(TEST_M * lda * sizeof(float));
    float *x = malloc(TEST_N * sizeof(float));
    float *y_opt = malloc(TEST_M * sizeof(float));
    float *y_ref = malloc(TEST_M * sizeof(float));
    if (!a || !x || !y_opt || !y_ref) return;

    fill_matrix(a, TEST_M, TEST_N, lda, 0.1f);
    fill_vector(x, TEST_N, 0.2f);
    fill_vector(y_opt, TEST_M, 0.3f);
    memcpy(y_ref, y_opt, TEST_M * sizeof(float));

    float alpha = 2.0f, beta = 0.5f;

    for (int i = 0; i < WARMUP_ITERATIONS; ++i)
        cblas_sgemv(CblasRowMajor, CblasNoTrans, TEST_M, TEST_N, alpha, a, lda, x, 1, beta, y_opt, 1);
    double t_opt_start = get_seconds();
    for (int i = 0; i < BENCHMARK_ITERATIONS; ++i)
        cblas_sgemv(CblasRowMajor, CblasNoTrans, TEST_M, TEST_N, alpha, a, lda, x, 1, beta, y_opt, 1);
    double t_opt = get_seconds() - t_opt_start;

    double t_ref_start = get_seconds();
    for (int i = 0; i < BENCHMARK_ITERATIONS; ++i)
        ref_sgemv(CblasRowMajor, CblasNoTrans, TEST_M, TEST_N, alpha, a, lda, x, 1, beta, y_ref, 1);
    double t_ref = get_seconds() - t_ref_start;

    double flops = 2.0 * TEST_M * TEST_N;
    double gflops_opt = calc_gflops(flops, t_opt, BENCHMARK_ITERATIONS);
    double gflops_ref = calc_gflops(flops, t_ref, BENCHMARK_ITERATIONS);

    float diff = max_abs_diff(y_opt, y_ref, TEST_M);
    printf("sgemv: ref=%.6fs(%7.2f GFLOPS) opt=%.6fs(%7.2f GFLOPS) speedup=%.2fx max_diff=%.6f %s\n",
           t_ref, gflops_ref, t_opt, gflops_opt, t_ref/t_opt, diff, diff < TOLERANCE ? "PASS" : "FAIL");

    free(a); free(x); free(y_opt); free(y_ref);
}

static void benchmark_sger(void) {
    int lda = TEST_N;
    float *a_opt = malloc(TEST_M * lda * sizeof(float));
    float *a_ref = malloc(TEST_M * lda * sizeof(float));
    float *x = malloc(TEST_M * sizeof(float));
    float *y = malloc(TEST_N * sizeof(float));
    if (!a_opt || !a_ref || !x || !y) return;

    fill_matrix(a_opt, TEST_M, TEST_N, lda, 0.1f);
    memcpy(a_ref, a_opt, TEST_M * lda * sizeof(float));
    fill_vector(x, TEST_M, 0.2f);
    fill_vector(y, TEST_N, 0.3f);
    float alpha = 2.0f;

    for (int i = 0; i < WARMUP_ITERATIONS; ++i)
        cblas_sger(CblasRowMajor, TEST_M, TEST_N, alpha, x, 1, y, 1, a_opt, lda);
    double t_opt_start = get_seconds();
    for (int i = 0; i < BENCHMARK_ITERATIONS; ++i)
        cblas_sger(CblasRowMajor, TEST_M, TEST_N, alpha, x, 1, y, 1, a_opt, lda);
    double t_opt = get_seconds() - t_opt_start;

    double t_ref_start = get_seconds();
    for (int i = 0; i < BENCHMARK_ITERATIONS; ++i)
        ref_sger(CblasRowMajor, TEST_M, TEST_N, alpha, x, 1, y, 1, a_ref, lda);
    double t_ref = get_seconds() - t_ref_start;

    double flops = 2.0 * TEST_M * TEST_N;
    double gflops_opt = calc_gflops(flops, t_opt, BENCHMARK_ITERATIONS);
    double gflops_ref = calc_gflops(flops, t_ref, BENCHMARK_ITERATIONS);

    float diff = max_abs_diff(a_opt, a_ref, TEST_M * TEST_N);
    printf("sger:  ref=%.6fs(%7.2f GB/s) opt=%.6fs(%7.2f GFLOPS) speedup=%.2fx max_diff=%.6f %s\n",
           t_ref, gflops_ref, t_opt, gflops_opt, t_ref/t_opt, diff, diff < TOLERANCE ? "PASS" : "FAIL");

    free(a_opt); free(a_ref); free(x); free(y);
}

static void benchmark_sgemm(void) {
    int lda = TEST_K, ldb = TEST_N, ldc = TEST_N;
    float *a = malloc(TEST_M * lda * sizeof(float));
    float *b = malloc(TEST_K * ldb * sizeof(float));
    float *c_opt = malloc(TEST_M * ldc * sizeof(float));
    float *c_ref = malloc(TEST_M * ldc * sizeof(float));
    if (!a || !b || !c_opt || !c_ref) return;

    fill_matrix(a, TEST_M, TEST_K, lda, 0.1f);
    fill_matrix(b, TEST_K, TEST_N, ldb, 0.2f);
    fill_matrix(c_opt, TEST_M, TEST_N, ldc, 0.3f);
    memcpy(c_ref, c_opt, TEST_M * ldc * sizeof(float));

    float alpha = 2.0f, beta = 0.5f;

    for (int i = 0; i < WARMUP_ITERATIONS; ++i)
        cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, TEST_M, TEST_N, TEST_K,
                    alpha, a, lda, b, ldb, beta, c_opt, ldc);
    double t_opt_start = get_seconds();
    for (int i = 0; i < BENCHMARK_ITERATIONS; ++i)
        cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, TEST_M, TEST_N, TEST_K,
                    alpha, a, lda, b, ldb, beta, c_opt, ldc);
    double t_opt = get_seconds() - t_opt_start;

    double t_ref_start = get_seconds();
    for (int i = 0; i < BENCHMARK_ITERATIONS; ++i)
        ref_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, TEST_M, TEST_N, TEST_K,
                  alpha, a, lda, b, ldb, beta, c_ref, ldc);
    double t_ref = get_seconds() - t_ref_start;

    double flops = 2.0 * TEST_M * TEST_N * TEST_K;
    double gflops_opt = calc_gflops(flops, t_opt, BENCHMARK_ITERATIONS);
    double gflops_ref = calc_gflops(flops, t_ref, BENCHMARK_ITERATIONS);

    float diff = max_abs_diff(c_opt, c_ref, TEST_M * TEST_N);
    printf("sgemm: ref=%.6fs(%7.2f GFLOPS) opt=%.6fs(%7.2f GFLOPS) speedup=%.2fx max_diff=%.6f %s\n",
           t_ref, gflops_ref, t_opt, gflops_opt, t_ref/t_opt, diff, diff < TOLERANCE ? "PASS" : "FAIL");

    free(a); free(b); free(c_opt); free(c_ref);
}

static void benchmark_ssyrk(void) {
    int lda = TEST_K, ldc = TEST_M;
    float *a = malloc(TEST_M * lda * sizeof(float));
    float *c_opt = malloc(TEST_M * ldc * sizeof(float));
    float *c_ref = malloc(TEST_M * ldc * sizeof(float));
    if (!a || !c_opt || !c_ref) return;

    fill_matrix(a, TEST_M, TEST_K, lda, 0.1f);
    fill_symmetric(c_opt, TEST_M, ldc, 0.2f);
    memcpy(c_ref, c_opt, TEST_M * ldc * sizeof(float));

    float alpha = 2.0f, beta = 0.5f;

    for (int i = 0; i < WARMUP_ITERATIONS; ++i)
        cblas_ssyrk(CblasRowMajor, CblasUpper, CblasNoTrans, TEST_M, TEST_K,
                    alpha, a, lda, beta, c_opt, ldc);
    double t_opt_start = get_seconds();
    for (int i = 0; i < BENCHMARK_ITERATIONS; ++i)
        cblas_ssyrk(CblasRowMajor, CblasUpper, CblasNoTrans, TEST_M, TEST_K,
                    alpha, a, lda, beta, c_opt, ldc);
    double t_opt = get_seconds() - t_opt_start;

    double t_ref_start = get_seconds();
    for (int i = 0; i < BENCHMARK_ITERATIONS; ++i)
        ref_ssyrk(CblasRowMajor, CblasUpper, CblasNoTrans, TEST_M, TEST_K,
                  alpha, a, lda, beta, c_ref, ldc);
    double t_ref = get_seconds() - t_ref_start;

    // SYRK computes C = A*A^T, symmetric output, ~half the work of GEMM
    double flops = TEST_M * TEST_M * TEST_K; // n^2 * k (approximately)
    double gflops_opt = calc_gflops(flops, t_opt, BENCHMARK_ITERATIONS);
    double gflops_ref = calc_gflops(flops, t_ref, BENCHMARK_ITERATIONS);

    float diff = max_abs_diff(c_opt, c_ref, TEST_M * ldc);
    printf("ssyrk: ref=%.6fs(%7.2f GFLOPS) opt=%.6fs(%7.2f GFLOPS) speedup=%.2fx max_diff=%.6f %s\n",
           t_ref, gflops_ref, t_opt, gflops_opt, t_ref/t_opt, diff, diff < TOLERANCE ? "PASS" : "FAIL");

    free(a); free(c_opt); free(c_ref);
}

int main(int argc, char **argv) {
    printf("=== CBLAS Vectorization Benchmark ===\n");
    printf("Test sizes: N=%d, M=%d, K=%d\n", TEST_N, TEST_M, TEST_K);
    printf("Iterations: warmup=%d, benchmark=%d\n", WARMUP_ITERATIONS, BENCHMARK_ITERATIONS);
    printf("FLOP counts:\n");
    printf("  saxpy: 2*N = %lld\n", 2LL * TEST_N);
    printf("  sdot:  2*N = %lld\n", 2LL * TEST_N);
    printf("  sscal: N   = %lld\n", (long long)TEST_N);
    printf("  sgemv: 2*M*N = %lld\n", 2LL * TEST_M * TEST_N);
    printf("  sger:  2*M*N = %lld\n", 2LL * TEST_M * TEST_N);
    printf("  sgemm: 2*M*N*K = %lld\n", 2LL * TEST_M * TEST_N * TEST_K);
    printf("  ssyrk: N*N*K = %lld\n", (long long)TEST_M * TEST_M * TEST_K);
    printf("======================================\n\n");

    benchmark_saxpy();
    benchmark_scopy();
    benchmark_sdot();
    benchmark_sscal();
    benchmark_sgemv();
    benchmark_sger();
    benchmark_sgemm();
    benchmark_ssyrk();

    return 0;
}