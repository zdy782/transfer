#include <arm_sve.h>
#include "../blas_case_common.h"

void cblas_saxpy(int n, float alpha, const float *x, int incx, float *y, int incy) {
    if (n <= 0) {
        return;
    }

    if (incx == 1 && incy == 1) {
        const int vl = (int)svcntw();
        svfloat32_t valpha = svdup_n_f32(alpha);

        for (int i = 0; i < n; i += vl) {
            svbool_t pg = svwhilelt_b32((uint64_t)i, (uint64_t)n);
            svfloat32_t vx = svld1_f32(pg, x + i);
            svfloat32_t vy = svld1_f32(pg, y + i);
            vy = svmla_f32_x(pg, vy, valpha, vx);
            svst1_f32(pg, y + i, vy);
        }
        return;
    }

    {
        int ix = 0;
        int iy = 0;
        for (int index = 0; index < n; ++index) {
            y[iy] += alpha * x[ix];
            ix += incx;
            iy += incy;
        }
    }
}