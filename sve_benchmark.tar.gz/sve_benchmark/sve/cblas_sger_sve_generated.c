#include <arm_sve.h>
#include "../blas_case_common.h"

void cblas_sger(
    CBLAS_ORDER order,
    int m,
    int n,
    float alpha,
    const float *x,
    int incx,
    const float *y,
    int incy,
    float *a,
    int lda
) {
    if (order != CblasRowMajor || incx != 1 || incy != 1) {
        return;
    }

    const int vl = (int)svcntw();

    for (int row = 0; row < m; ++row) {
        float scaled_x = alpha * x[row];
        svfloat32_t vscaled_x = svdup_n_f32(scaled_x);

        for (int col = 0; col < n; col += vl) {
            svbool_t pg = svwhilelt_b32((uint64_t)col, (uint64_t)n);
            svfloat32_t vy = svld1_f32(pg, y + col);
            svfloat32_t va = svld1_f32(pg, a + row * lda + col);
            va = svmla_f32_x(pg, va, vscaled_x, vy);
            svst1_f32(pg, a + row * lda + col, va);
        }
    }
}