#include <arm_sve.h>
#include "../../blas_case_common.h"

void cblas_sscal(int n, float alpha, float *x, int incx) {
    if (n <= 0) {
        return;
    }

    if (incx == 1) {
        const int vl = (int)svcntw();
        svfloat32_t valpha = svdup_n_f32(alpha);

        for (int i = 0; i < n; i += vl) {
            svbool_t pg = svwhilelt_b32((uint64_t)i, (uint64_t)n);
            svfloat32_t vx = svld1_f32(pg, x + i);
            vx = svmul_f32_x(pg, vx, valpha);
            svst1_f32(pg, x + i, vx);
        }
        return;
    }

    {
        int ix = 0;
        for (int index = 0; index < n; ++index) {
            x[ix] *= alpha;
            ix += incx;
        }
    }
}