#include <arm_sve.h>
#include "../blas_case_common.h"

void cblas_sgemm(
    CBLAS_ORDER order,
    CBLAS_TRANSPOSE transa,
    CBLAS_TRANSPOSE transb,
    int m,
    int n,
    int k,
    float alpha,
    const float *a,
    int lda,
    const float *b,
    int ldb,
    float beta,
    float *c,
    int ldc
) {
    if (order != CblasRowMajor || transa != CblasNoTrans || transb != CblasNoTrans) {
        return;
    }

    const int vl = (int)svcntw();

    for (int row = 0; row < m; ++row) {
        // Scale C row by beta
        for (int col = 0; col < n; col += vl) {
            svbool_t pg = svwhilelt_b32((uint64_t)col, (uint64_t)n);
            svfloat32_t vc = svld1_f32(pg, c + row * ldc + col);
            vc = svmul_f32_x(pg, vc, svdup_n_f32(beta));
            svst1_f32(pg, c + row * ldc + col, vc);
        }

        for (int depth = 0; depth < k; ++depth) {
            float scaled_a = alpha * a[row * lda + depth];
            svfloat32_t vscaled_a = svdup_n_f32(scaled_a);

            for (int col = 0; col < n; col += vl) {
                svbool_t pg = svwhilelt_b32((uint64_t)col, (uint64_t)n);
                svfloat32_t vb = svld1_f32(pg, b + depth * ldb + col);
                svfloat32_t vc = svld1_f32(pg, c + row * ldc + col);
                vc = svmla_f32_x(pg, vc, vscaled_a, vb);
                svst1_f32(pg, c + row * ldc + col, vc);
            }
        }
    }
}