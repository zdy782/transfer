#include <arm_sve.h>
#include "../blas_case_common.h"

void cblas_ssyrk(
    CBLAS_ORDER order,
    CBLAS_UPLO uplo,
    CBLAS_TRANSPOSE trans,
    int n,
    int k,
    float alpha,
    const float *a,
    int lda,
    float beta,
    float *c,
    int ldc
) {
    if (order != CblasRowMajor || uplo != CblasUpper || trans != CblasNoTrans) {
        return;
    }

    const int vl = (int)svcntw();

    for (int row = 0; row < n; ++row) {
        for (int col = row; col < n; ++col) {
            svfloat32_t vacc = svdup_n_f32(0.0f);

            for (int depth = 0; depth < k; depth += vl) {
                svbool_t pg = svwhilelt_b32((uint64_t)depth, (uint64_t)k);
                svfloat32_t va_row = svld1_f32(pg, a + row * lda + depth);
                svfloat32_t va_col = svld1_f32(pg, a + col * lda + depth);
                vacc = svmla_f32_x(pg, vacc, va_row, va_col);
            }

            // Horizontal reduction using svaddv_f32
            svbool_t pg_all = svptrue_b32();
            float accum = svaddv_f32(pg_all, vacc);

            c[row * ldc + col] = (alpha * accum) + (beta * c[row * ldc + col]);
        }
    }
}