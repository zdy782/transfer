#include <arm_sve.h>
#include "../../blas_case_common.h"

void cblas_sgemv(
    CBLAS_ORDER order,
    CBLAS_TRANSPOSE trans,
    int m,
    int n,
    float alpha,
    const float *a,
    int lda,
    const float *x,
    int incx,
    float beta,
    float *y,
    int incy
) {
    if (order != CblasRowMajor || trans != CblasNoTrans || incx != 1 || incy != 1) {
        return;
    }

    const int vl = (int)svcntw();

    for (int row = 0; row < m; ++row) {
        svfloat32_t vacc = svdup_n_f32(0.0f);

        for (int col = 0; col < n; col += vl) {
            svbool_t pg = svwhilelt_b32((uint64_t)col, (uint64_t)n);
            svfloat32_t va_row = svld1_f32(pg, a + row * lda + col);
            svfloat32_t vx = svld1_f32(pg, x + col);
            vacc = svmla_f32_x(pg, vacc, va_row, vx);
        }

        // Horizontal reduction using svaddv_f32
        svbool_t pg_all = svptrue_b32();
        float accum = svaddv_f32(pg_all, vacc);

        y[row] = (alpha * accum) + (beta * y[row]);
    }
}