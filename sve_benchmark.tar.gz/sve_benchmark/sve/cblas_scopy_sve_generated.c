#include <arm_sve.h>
#include "../../blas_case_common.h"

void cblas_scopy(int n, const float *x, int incx, float *y, int incy) {
    if (n <= 0) {
        return;
    }

    if (incx == 1 && incy == 1) {
        const int vl = (int)svcntw();

        for (int i = 0; i < n; i += vl) {
            svbool_t pg = svwhilelt_b32((uint64_t)i, (uint64_t)n);
            svfloat32_t vx = svld1_f32(pg, x + i);
            svst1_f32(pg, y + i, vx);
        }
        return;
    }

    {
        int ix = 0;
        int iy = 0;
        for (int index = 0; index < n; ++index) {
            y[iy] = x[ix];
            ix += incx;
            iy += incy;
        }
    }
}