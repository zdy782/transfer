#include <arm_sve.h>
#include "../../blas_case_common.h"

float cblas_sdot(int n, const float *x, int incx, const float *y, int incy) {
    float accum = 0.0f;

    if (n <= 0) {
        return 0.0f;
    }

    if (incx == 1 && incy == 1) {
        const int vl = (int)svcntw();
        svfloat32_t vacc = svdup_n_f32(0.0f);

        for (int i = 0; i < n; i += vl) {
            svbool_t pg = svwhilelt_b32((uint64_t)i, (uint64_t)n);
            svfloat32_t vx = svld1_f32(pg, x + i);
            svfloat32_t vy = svld1_f32(pg, y + i);
            vacc = svmla_f32_x(pg, vacc, vx, vy);
        }

        // Horizontal reduction using svaddv_f32
        svbool_t pg_all = svptrue_b32();
        accum = svaddv_f32(pg_all, vacc);
        return accum;
    }

    {
        int ix = 0;
        int iy = 0;
        for (int index = 0; index < n; ++index) {
            accum += x[ix] * y[iy];
            ix += incx;
            iy += incy;
        }
    }
    return accum;
}